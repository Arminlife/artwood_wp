<?php
/* Template Name: Home page */
get_header();
?>

  <?php get_template_part('template_parts/home_page/hero_block'); ?>
  <?php get_template_part('template_parts/universal/contacts_block'); ?>

<?php get_footer();
