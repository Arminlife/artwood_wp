<svg class="icon icon-arrow link_mod">
  <use xlink:href="<?php bloginfo('template_url') ?>/imgs/sprite/sprite.svg#arrow"></use>
</svg>