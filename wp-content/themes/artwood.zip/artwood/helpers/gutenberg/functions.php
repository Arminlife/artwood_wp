<?php

require_once ( TEMPLATEPATH . '/inc/functions/register_new_blocks.php' );
require_once ( TEMPLATEPATH . '/inc/MTDBlocks.php' );