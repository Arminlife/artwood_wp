Advanced Editor Tools (previously TinyMCE Advanced) - Extends and enhances the block editor (Gutenberg) and the classic editor (TinyMCE).
                                                      Раcширяет стандартный редактор текста.

Maintenance - Put your site in maintenance mode, away from the public view. Use maintenance plugin if your website is in development or you need to change a few things, run an upgrade. Make it only accessible to logged in users.
              Закрывает сайт на обслуживание.

Safe SVG - Allows SVG uploads into WordPress and sanitizes the SVG before saving it

Flamingo - A trustworthy message storage plugin for Contact Form 7.
           Плагин для подписок, дублирует входящие сообщения и данные CF7

Query Monitor - The Developer Tools Panel for WordPress.

WP Mail SMTP - Reconfigures the wp_mail() function to use Gmail/Mailgun/SendGrid/SMTP instead of the default mail() and creates an options page to manage the settings.
              Настройка конфигурации SMTP сервера.
мануал https://www.ukraine.com.ua/wiki/hosting/cms/wordpress/plugins/mail/

Duplicate Page - Duplicate Posts, Pages and Custom Posts using single click.