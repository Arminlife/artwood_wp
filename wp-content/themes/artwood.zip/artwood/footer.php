			</div><!-- .base# -->

			<footer class="footer">this is foooter!!!</footer>

		</div><!-- .wrapper# -->

		<?php wp_footer(); ?>

	</body>
</html>